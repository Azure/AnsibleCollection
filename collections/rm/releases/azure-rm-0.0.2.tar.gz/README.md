
# version 0.0.1:
  managementgroup
  managementgroupsubscription
  subscriptionfactory
# version 0.0.2:
  apimanagementservice
  apimanagementapi
