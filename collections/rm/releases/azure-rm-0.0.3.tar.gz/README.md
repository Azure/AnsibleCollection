
# version 0.0.1:
  managementgroup
  managementgroupsubscription
  subscriptionfactory
# version 0.0.2:
  apimanagementservice
  apimanagementapi
# version 0.0.3:
  apimanagementapischema
  apimanagementapitagdescription
  apimanagementcache
  apimanagementgroup
  apimanagementgroupuser
  apimanagementnotification
  apimanagementnotificationrecipientemail
  apimanagementnotificationrecipientuser
  apimanagementopenidconnectprovider
  apimanagementpolicy
  apimanagementproduct
  apimanagementproductapi
  apimanagementproductgroup
  apimanagementproductpolicy
  apimanagementproperty
  apimanagementtag
  apimanagementuser
